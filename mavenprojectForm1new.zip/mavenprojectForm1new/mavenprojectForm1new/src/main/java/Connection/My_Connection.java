/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Connection;
import com.mysql.cj.jdbc.MysqlDataSource;
import java.sql.Connection;
//import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;
//import com.sun.istack.internal.logging.Logger;
import java.sql.SQLException;
import java.util.logging.Level;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author tttt
 */
public class My_Connection {


public Connection  createconnection(){


Connection connection=null;

MysqlDataSource mds=new MysqlDataSource();

mds.setServerName("localhost");
mds.setPortNumber(3306);
mds.setUser("root");
mds.setPassword("");
mds.setDatabaseName("hotel_booking");

try{
  connection = mds.getConnection();
} catch(SQLException e){
Logger.getLogger((My_Connection.class.getName())).log(Level.SEVERE,null,e);
}
return connection;
}
    
}
