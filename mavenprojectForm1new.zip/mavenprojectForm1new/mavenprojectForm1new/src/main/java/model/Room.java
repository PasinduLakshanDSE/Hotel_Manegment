/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import Connection.My_Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author tttt
 */
public class Room {


My_Connection my_connection=new  My_Connection();


public void fillRoomTypeTable(JTable table) {
PreparedStatement ps;
ResultSet rs;
String selectQuery="SELECT * FROM type;";

try{
   ps=my_connection.createconnection().prepareStatement(selectQuery);
   rs=ps.executeQuery();
   DefaultTableModel tableModel= (DefaultTableModel)table.getModel();
   
    Object[]row;

     while(rs.next()){
       row=new Object[3];
       row[0]=rs.getInt(1);
       row[1]=rs.getString(2);
       row[2]=rs.getString(3);
       

     tableModel.addRow(row);
       
}
}catch(SQLException e){
//Logger.getLogger((My_Connection.class.getName())).log(Level.SEVERE,null,e);
System.out.println(e.getMessage());
}
    
}

public void fillRoomTypeComboBox(JComboBox combobox) {
PreparedStatement ps;
ResultSet rs;
String selectQuery="SELECT * FROM type;";

try{
   ps=my_connection.createconnection().prepareStatement(selectQuery);
   rs=ps.executeQuery();
   
   
    

     while(rs.next()){
      
       
       

     combobox.addItem(rs.getInt(1));
       
}
}catch(SQLException e){
//Logger.getLogger((My_Connection.class.getName())).log(Level.SEVERE,null,e);
System.out.println(e.getMessage());
}
    
}


public void fillRoomJTable(JTable table) {
PreparedStatement ps;
ResultSet rs;
String selectQuery="SELECT * FROM room;";

try{
   ps=my_connection.createconnection().prepareStatement(selectQuery);
   rs=ps.executeQuery();
   DefaultTableModel tableModel= (DefaultTableModel)table.getModel();
   
    Object[]row;

     while(rs.next()){
       row=new Object[4];
       row[0]=rs.getInt(1);
       row[1]=rs.getInt(2);
       row[2]=rs.getString(3);
       row[3]=rs.getString(4);
      

     tableModel.addRow(row);
       
}
}catch(SQLException e){
//Logger.getLogger((My_Connection.class.getName())).log(Level.SEVERE,null,e);
System.out.println(e.getMessage());
}
    
}


public boolean addRoom(int number,int type,String phone){
PreparedStatement st;
ResultSet rs;
String addQuery="INSERT INTO room (r_number, type, phone, reserved)\n" +
"VALUES (?, ?, ?, ?);";

try{
st=my_connection.createconnection().prepareStatement(addQuery);

st.setInt(1, number);
st.setInt(2, type);
st.setString(3, phone);
//room is free or not
st.setString(4, "NO");


 return (st.executeUpdate()>0);

}catch(SQLException e){
//Logger.getLogger((My_Connection.class.getName())).log(Level.SEVERE,null,e);
System.out.println(e.getMessage());
return false;
}



}


   public boolean editRoom(int number,int type,String phone,String isReserved){
 PreparedStatement st;
ResultSet rs;
String updateQuery="UPDATE room SET type= ?, phone= ?, reserved=?  WHERE r_number= ?;";

try{
st=my_connection.createconnection().prepareStatement(updateQuery);

st.setInt(1,type);
st.setString(2, phone);

st.setString(3, isReserved);
st.setInt(4,number);


  return (st.executeUpdate()>0);


}catch(SQLException e){
//Logger.getLogger((My_Connection.class.getName())).log(Level.SEVERE,null,e);
System.out.println(e.getMessage());
return false;
}
}


public boolean removeRoom(int roomNumber){
PreparedStatement st;
ResultSet rs;
String deleteQuery="DELETE FROM room WHERE r_number=?;";

try{
st=my_connection.createconnection().prepareStatement(deleteQuery);


st.setInt(1,roomNumber);


  return (st.executeUpdate()>0);


}catch(SQLException e){
//Logger.getLogger((My_Connection.class.getName())).log(Level.SEVERE,null,e);
System.out.println(e.getMessage());
return false;
}
}
    
}
