
package model;

import Connection.My_Connection;
//import com.sun.istack.internal.logging.Logger;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
//import static jdk.nashorn.internal.runtime.Debug.id;

/**
 *
 * @author tttt
 */
public class Client {

My_Connection my_connection=new My_Connection();
    private int id;




public boolean addClient(String fname,String lname,String phone,String email){
PreparedStatement st;
ResultSet rs;
String addQuery="INSERT INTO client (first_name, last_name, phone_no, email)\n" +
"VALUES (?, ?, ?, ?);";

try{
st=my_connection.createconnection().prepareStatement(addQuery);

st.setString(1, fname);
st.setString(2, lname);
st.setString(3, phone);
st.setString(4, email);

 return (st.executeUpdate()>0);

}catch(SQLException e){
//Logger.getLogger((My_Connection.class.getName())).log(Level.SEVERE,null,e);
System.out.println(e.getMessage());
return false;
}



}

    /**
     *
     * @param id
     * @param fname
     * @param lname
     * @param phone
     * @param email
     * @return
     */
    public boolean editClient(int id,String fname,String lname,String phone,String email){
 PreparedStatement st;
ResultSet rs;
String updateQuery="UPDATE client SET first_name=?, last_name=?, phone_no=?, email=? WHERE id=?;";

try{
st=my_connection.createconnection().prepareStatement(updateQuery);

st.setString(1, fname);
st.setString(2, lname);
st.setString(3, phone);
st.setString(4, email);
st.setInt(5,id);


  return (st.executeUpdate()>0);


}catch(SQLException e){
//Logger.getLogger((My_Connection.class.getName())).log(Level.SEVERE,null,e);
System.out.println(e.getMessage());
return false;
}
}

public boolean removeClient(int id){
PreparedStatement st;
ResultSet rs;
String deleteQuery="DELETE FROM client WHERE id=?;";

try{
st=my_connection.createconnection().prepareStatement(deleteQuery);


st.setInt(1,id);


  return (st.executeUpdate()>0);


}catch(SQLException e){
//Logger.getLogger((My_Connection.class.getName())).log(Level.SEVERE,null,e);
System.out.println(e.getMessage());
return false;
}
}

public void fillClientTable(JTable table) {
PreparedStatement ps;
ResultSet rs;
String selectQuery="SELECT * FROM client;";

try{
   ps=my_connection.createconnection().prepareStatement(selectQuery);
   rs=ps.executeQuery();
   DefaultTableModel tableModel= (DefaultTableModel)table.getModel();
   
    Object[]row;

     while(rs.next()){
       row=new Object[5];
       row[0]=rs.getInt(1);
       row[1]=rs.getString(2);
       row[2]=rs.getString(3);
       row[3]=rs.getString(4);
      row[4]=rs.getString(5);

     tableModel.addRow(row);
       
}
}catch(SQLException e){
//Logger.getLogger((My_Connection.class.getName())).log(Level.SEVERE,null,e);
System.out.println(e.getMessage());
}
    
}

   /* public boolean removeClient(int id) {
       throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public boolean removeClient(int id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody

    public boolean removeClient(int id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    }

    public boolean editClient(int id, String fname, String lname, String phone, String email) {
       throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
*/}
